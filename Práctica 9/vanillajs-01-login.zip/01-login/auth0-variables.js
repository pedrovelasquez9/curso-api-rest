var AUTH0_CLIENT_ID='-nlUWYvE1QmJfa31bZZj7jSrIO2U7qLR';
var AUTH0_DOMAIN='pjpv9011.eu.auth0.com';
var AUTH0_CALLBACK_URL=location.href;